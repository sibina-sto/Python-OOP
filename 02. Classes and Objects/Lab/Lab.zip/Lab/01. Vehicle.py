class Vehicle:
    def __init__(self, mileage, max_speed = 150):
        self.mileage = mileage
        self.max_speed = max_speed
        self.gadgets = []

# car = Vehicle(20)
# print(car.max_speed)
# print(car.mileage)
# print(car.gadgets)
# car.gadgets.append("Hudly Wireless")
# print(car.gadgets)
# car2 = Vehicle(10000)
# print(car2.gadgets)
# print(car.gadgets)