# Ines

from functools import reduce

class Calculator:
    @staticmethod
    def add(*args):
        return sum(args)

    @staticmethod
    def multiply(*args):
        return reduce(lambda x, y: x * y, args)

    @staticmethod
    def divide(*args):
        return reduce(lambda x, y: x / y, args)

    @staticmethod
    def subtract(*args):
        return reduce(lambda x, y: x - y, args)

print(Calculator.add(5, 10, 4))
print(Calculator.multiply(1, 2, 3, 5))
print(Calculator.divide(100, 2))
print(Calculator.subtract(90, 20, -50, 43, 7))


# class Calculator:
#     @staticmethod
#     def add(*args):
#         num = args[0]
#         for nums in range(1, len(args)):
#             num += args[nums]
#         return num
# 
#     @staticmethod
#     def multiply(*args):
#         num = args[0]
#         for nums in range(1, len(args)):
#             num *= args[nums]
#         return num
# 
#     @staticmethod
#     def divide(*args):
#         num = args[0]
#         for nums in range(1, len(args)):
#             num /= args[nums]
#         return num
# 
#     @staticmethod
#     def subtract(*args):
#         num = args[0]
#         for nums in range(1, len(args)):
#             num -= args[nums]
#         return num
# 
# print(Calculator.add(5, 10, 4))
# print(Calculator.multiply(1, 2, 3, 5))
# print(Calculator.divide(100, 2))
# print(Calculator.subtract(90, 20, -50, 43, 7))