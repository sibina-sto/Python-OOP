# from inheritance_exercises.restaurant.project.beverage.hot_beverage import HotBeverage
from project.beverage.hot_beverage import HotBeverage


class Tea(HotBeverage):
    pass