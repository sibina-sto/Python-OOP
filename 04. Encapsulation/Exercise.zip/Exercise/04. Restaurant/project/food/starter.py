# from inheritance_exercises.restaurant.project.food.food import Food
from project.food.food import Food


class Starter(Food):
    pass