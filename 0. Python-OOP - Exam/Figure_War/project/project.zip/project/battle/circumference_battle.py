from typing import ClassVar

from project.battle.battle import Battle


class CircumferenceBattle(Battle):
    _attr: ClassVar[str] = 'circumference'